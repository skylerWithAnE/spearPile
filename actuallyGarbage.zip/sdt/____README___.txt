This directory contains various tests for shakespeare code.
